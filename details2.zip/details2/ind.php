<?php
extract($_GET);
$i="http://localhost/details2/ind.php?clientId=".$clientId;
$index="http://localhost/details2/index1.php?clientId=".$clientId;
$status="http://localhost/details2/stat.php?clientId=".$clientId;
$cart="http://localhost/details2/cart1.php?clientId=".$clientId;
$orderec="http://localhost/details2/orderec.php?clientId=".$clientId;
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TAP TO ORDER</title>

<link href="tooplate_style.css" rel="stylesheet" type="text/css" />


</head>
<body> 

<div id="tooplate_header_wrapper">
	<div id="tooplate_header">
    
    	<div id="site_title">
            <h1><font color="white" size="3" ><span>TAP TO ORDER</span></font></h1>
        </div> 
        
        
    
    </div>
</div>

<div id="tooplate_middle_wrapper">
	<div id="tooplate_middle">
    
    	
        
        
        	<center><h1>WELCOME TO TAP TO ORDER</h1><center>
			<br />
			<br />
            <h3>NOW WE WILL AUTOMATE ALL YOUR NEEDS!</h3>
			<br />
			
			<p>Target the local grocer for your everyday supplies and promote local businesses too!<p>
			
            
        
    
    </div>
</div>

 <div id="tooplate_menu">
                
    <ul>
        <li><a href="<?php echo $i ?>" class="current">Home</a></li>
        <li><a href="<?php echo $index ?>">Details</a></li>
        <li><a href="<?php echo $status ?>">Status</a></li>
		
        <li><a href="<?php echo $cart ?>">Cart</a></li>
		<li><a href="http://localhost/details2/heat4.html">Visualisation</a></li>
    </ul>    	

	<div class="cleaner"></div>
</div> 
    
  
<div id="tooplate_footer_wrapper">

     
     
</div> 

</body>
</html>