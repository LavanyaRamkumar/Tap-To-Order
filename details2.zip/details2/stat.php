<?php
extract($_GET);
$i="http://localhost/details2/ind.php?clientId=".$clientId;
$index="http://localhost/details2/index1.php?clientId=".$clientId;
$status="http://localhost/details2/stat.php?clientId=".$clientId;
$cart="http://localhost/details2/cart1.php?clientId=".$clientId;
$orderec="http://localhost/details2/orderec.php?clientId=".$clientId;
$status='status.php?clientId='.$clientId;
?>





<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" >
<title></title>
</head>
<body>
<div id="show"></div>
<script type="text/javascript" src="jquery-3.2.1.min.js"></script>
<script type="text/javascript">
var a="<?php echo $status;?>";
$(document).ready(function(){
setInterval(function(){
$('#show').load(a)
},3000);
});
</script>
</body>
</html>