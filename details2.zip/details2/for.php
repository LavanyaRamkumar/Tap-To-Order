



<?php
exec("Rscript C:\Users\user\Desktop\a.R ");
$csvFile=file('C:\Users\user\Documents\test2.csv');
foreach($csvFile as $line){
  $data[]=str_getcsv($line);
}
echo "Month &nbsp &nbsp Forecast";
echo "<br>";
foreach($data as $row){

  if($row[1]!='se' && $row[0]!=''){
  echo $row[0];
  echo "&nbsp &nbsp";
  echo (10**$row[1]);
  echo "<br> </br>";
}
}
//echo "<img src='C:\Users\DELL\Documents\\rplot.png' >";
?>
<html>
<head>
<style>
#hi{
	position:absolute;
	top:50%;
	left:50%;
}
</style>
</head>
<body>
<div id="hi">
<img src="C:/Users/user/Documents/rplot.jpg" height="300" width="300"></img>
</div>
</body>
</html>