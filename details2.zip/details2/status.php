<?php

extract($_GET);
$i="http://localhost/details2/ind.php?clientId=".$clientId;
$index="http://localhost/details2/index1.php?clientId=".$clientId;
$status="http://localhost/details2/stat.php?clientId=".$clientId;
$newtb="newtb".$clientId;
$st="st".$clientId;
$sl1="sl1".$clientId;



$connect = mysql_connect("localhost","root","") or die('Database Not Connected. Please Fix the Issue! ' . mysql_error()); 
mysql_select_db("jsondb", $connect);
$jsonCont = file_get_contents('https://api.thingspeak.com/channels/294404/feeds.json?api_key=9EVJD7VDYKP2C34T&results=50');
$content = json_decode($jsonCont);
$query1="DELETE FROM $newtb";
mysql_query($query1,$connect);
foreach($content->feeds as $data)
{
$created_at=$data->created_at;
$entry_id=$data->entry_id;
$field1=$data->field1;


$query = "INSERT INTO $newtb(created_at,entry_id,field1) VALUES('$created_at','$entry_id','$field1')";
 if(!mysql_query($query,$connect)) 
 { die('Error : Query Not Executed. Please Fix the Issue! ' . mysql_error());
 } 



}
$result2 = mysql_query("SELECT MAX(field1)FROM $newtb");  //SELECT MAX(field1),MAX(entry_id) FROM jsontab
if (!$result2) {
trigger_error(mysql_error($result2));
}
while($row = mysql_fetch_assoc($result2))
{
$mf1 = $row["MAX(field1)"];

}

$result1=mysql_query("SELECT field1 FROM $newtb ORDER BY id DESC LIMIT 1");//SELECT field1,field2 FROM jsontab ORDER BY id DESC LIMIT 1
if (!$result1) {
	
trigger_error(mysql_error($result1));
}
while($row = mysql_fetch_assoc($result1))
{
$if1 = $row["field1"];
echo $if1;
}

$result3=mysql_query("SELECT item,threshold FROM $sl1 WHERE id=1");
if (!$result3) {
	
trigger_error(mysql_error($result3));
}
while($row = mysql_fetch_assoc($result3))
{
$i1 = $row["item"];
$t1=$row["threshold"];

}
$result11 = mysql_query("SELECT unit,wpu,num FROM $st");  //SELECT MAX(field1),MAX(entry_id) FROM jsontab
if (!$result11) {
trigger_error(mysql_error($result11));
}
while($row = mysql_fetch_assoc($result11))
{
$u = $row["unit"];
$wpu=$row["wpu"];
if($u=="cartons")
	$num=$row["num"];
	
}


?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="tooplate_style.css" rel="stylesheet" type="text/css" />

<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>
<link href="style.css" rel="stylesheet" type="text/css" media="all" />
<style>
#myTable {
    position:absolute;
           top:50%;
           left:30%;
    }
table, th, td {
    border: 1px solid white;
    border-collapse: collapse;
}

#hi {
    position:absolute;
           top:10%;
           left:40%;
    }

th{
  padding: 10px;
  text-align: center;
  font-weight: 500;
  font-size: 12px;
  color: #000;
  text-transform: uppercase;
}
td{
  padding: 10px;
  text-align: left;
  vertical-align:middle;
  font-weight: 300;
  font-size: 14px;
  color: #fff;
}
</style>
</head>
<body>
<script type="text/javascript" src="https://gc.kis.v2.scr.kaspersky-labs.com/5596A4A1-7F70-F147-8B80-B42E168DDC25/main.js" charset="UTF-8"></script><script>
document.addEventListener('DOMContentLoaded', function () {
  if (!Notification) {
    alert('Desktop notifications not available in your browser. Try Chromium.'); 
    return;
  }

  if (Notification.permission !== "granted")
    Notification.requestPermission();
});

function notifyMe() {
	/**var name="<?php echo $i1; ?>";
	console.log(name);
  if (Notification.permission !== "granted")
    Notification.requestPermission();
  else {
	  var temp = name+" below threshold! Order now!";
    var notification = new Notification('TAP TO ORDER', {
      icon: 'http://cdn.sstatic.net/stackexchange/img/logos/so/so-icon.png',
      body: temp,
    });

    notification.onclick = function () {
      window.open("http://stackoverflow.com/a/13328397/1269037");      
    };

  }**/

}
</script>
<?php
$l1=($if1/$wpu);
if ($l1<=$t1)
	  echo '<script>','notifyMe();','</script>';
?>

<div id="tooplate_header_wrapper">
	<div id="tooplate_header">
    
    	<div id="site_title">
            <h1><font color="white" size="3" ><span>TAP TO ORDER</span></font></h1>
        </div> <!-- end of site_title -->

        
        
    
    </div>
</div>


 <div id="tooplate_menu">
                
    <ul>
        <li><a href="<?php echo $i ?>" >Home</a></li>
        <li><a href="<?php echo $index ?>">Details</a></li>
        <li><a href="<?php echo $status ?>" class="current">Status</a></li>
    </ul>     	

	<div class="cleaner"></div>
</div> 
<h1></h1>
<center><h1>ITEM  STATUS</h1></center>
<table class="table table-hover" id="myTable" width="500" >
  <tbody>
    <tr bgcolor="DCDCDC">
      <th>ID</th>
      <th>Item</th>
      <th>Availability</th>
	  <th>Threshold</th>
	  <th> </th>
	  
    </tr>

<script>

var i="<?php echo $i1;?>";
//console.log(i);
		var xhr2 = new XMLHttpRequest();
		xhr2.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
				
                document.getElementById("1").innerHTML = this.responseText;
				console.log("data form the server"+xhr2.responseText);
            }
        };
		xhr2.open("get", "http://localhost/d.php?item="+i+"&clientId="+<?php echo $clientId;?>+"&p=orderlist", true);
		xhr2.send();
		console.log("sending...");
		</script>




    <tr>
	  <td>1</td>
	  <td><?php echo $i1; ?></td>
      <td><?php echo ($if1)." ".$u;if(isset($num))echo ($if1/$wpu)*$num." ".$i1?></td>
	  <td><?php echo $t1." ".$u;?></td>
	  <td> <button id="1" value="<?php echo $if1;?>" class="<?php echo $mf1;?>" onclick="myFunction(this,'<?php echo $i1; ?>')">Add to list</button> </td>
	  
	 
    </tr>
	
	</tbody>
</table>

	<div id="response"></div>
	
	

	


        <script>
		


            function myFunction(param,tx) {
			 
                //var change = document.getElementById("toggle");
                if (param.innerHTML == "Add to list")
                { 
                    param.innerHTML = "Added to list";
					var responseText = document.getElementById('response');
					var str_json = JSON.stringify({item: tx, status:"Added to list",clientId:<?php echo $clientId;?>,tab:"orderlist"});
					console.log(str_json);

    request= new XMLHttpRequest();

    request.open("POST", "c.php", true);

    request.setRequestHeader("Content-type", "application/json");
	request.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			document.getElementById("response").innerHTML = this.responseText;
				console.log("data form the server"+request.responseText);
            }
        };
    request.send(str_json);
			}}
			
	</script>
	


  
</div>
</div>