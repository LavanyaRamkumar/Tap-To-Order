<?php
//connect and select the database 
$connect = mysql_connect("localhost","root","") or die('Database Not Connected. Please Fix the Issue! ' . mysql_error()); 
mysql_select_db("jsondb", $connect);
extract($_GET);
echo $field1;
echo $clientId;
$sl1="sl1".$clientId;
echo $sl1;
$psl1="psl1".$clientId;
if(isset($field1)){
$query1 ="insert into $sl1 (id,item,threshold) VALUES (1,'$field1','$t1')ON DUPLICATE KEY UPDATE item='$field1',threshold='$t1'";
if(!mysql_query($query1,$connect)) 
 { die('Error : Query Not Executed. Please Fix the Issue! ' . mysql_error());
 } 
 else{ echo "Data1 Inserted Successully!!!"; }
}
if (isset($field2)){
$query2 ="insert into $sl1 (id,item,threshold) VALUES (2,'$field2','$t2')ON DUPLICATE KEY UPDATE item='$field2',threshold='$t2'";


 
 if(!mysql_query($query2,$connect)) 
 { die('Error : Query Not Executed. Please Fix the Issue! ' . mysql_error());
 } 
 else{ echo "Data2 Inserted Successully!!!"; }
}
 
 
header("Location:http://localhost/details2/ind.php?clientId=".$clientId);
exit;





?>

