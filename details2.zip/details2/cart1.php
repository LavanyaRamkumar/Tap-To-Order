<?php
extract($_GET);
$i="http://localhost/details2/ind.php?clientId=".$clientId;
$index="http://localhost/details2/index1.php?clientId=".$clientId;
$status="http://localhost/details2/status.php?clientId=".$clientId;
$cart="http://localhost/details2/cart1.php?clientId=".$clientId;
$slist="http://localhost/details2/slist1.php";
$orderec="http://localhost/details2/orderec.php?clientId=".$clientId;

?>

<html>
<head>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Tap To Order</title>
<meta name="keywords" content="corporate blue, theme, free templates, website templates, CSS, HTML" />
<meta name="description" content="Corporate Blue Theme is a free website template provided by tooplate.com" />
<link href="tooplate_style.css" rel="stylesheet" type="text/css" />

<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>
<link href="style.css" rel="stylesheet" type="text/css" media="all" />
<style>
#myTable {
    position:absolute;
           top:50%;
           left:30%;
    }
table, th, td {
    border: 1px solid white;
    border-collapse: collapse;
}

#hi {
    position:absolute;
           top:40%;
left:50%;}
#hm {
    position:absolute;
           top:90%;
left:90%;}
    
#hey{
	position:absolute;
           top:90%;
           left:70%;
	
}

th{
  padding: 10px;
  text-align: center;
  font-weight: 500;
  font-size: 12px;
  color: #000;
  text-transform: uppercase;
}
td{
  padding: 10px;
  text-align: left;
  vertical-align:middle;
  font-weight: 300;
  font-size: 14px;
  color: #fff;
}
</style>
</head>
<body>
<div id="tooplate_header_wrapper">
	<div id="tooplate_header">
    
    	<div id="site_title">
            <h1><font color="white" size="3" ><span>TAP TO ORDER</span></font></h1>
        </div> <!-- end of site_title -->
        
        
    
    </div>
</div>



 <div id="tooplate_menu">
                
    <ul>
        <li><a href="<?php echo $i ?>" >Home</a></li>
        <li><a href="<?php echo $index ?>">Details</a></li>
        <li><a href="<?php echo $status ?>" >Status</a></li>
		
        <li><a href="<?php echo $cart ?>" class="current">Cart</a></li>
	
		<li><a href="http://localhost/details2/heat4.html">Visualisation</a></li>
		<li><a href="http://localhost/details2/for.php">&nbspForecast</a></li>
    </ul>      	

	<div class="cleaner"></div>
</div> <!-- end of templatetooplate_menu -->
<h1 align="center" id="hi">CART</h1>
<table id="myTable">
<tr bgcolor="DCDCDC">
      <th>ID</th>
      <th>Item</th>
	  <th> </th>
	  
    </tr>

<?php
$conn = mysql_connect("localhost","root","");
mysql_select_db('jsondb', $conn);
//$username=$_GET["item"];
//$password=$_POST["Password"];
//$password1=$_POST["Password"];
//$email=$_POST["Email"];
$clientId=$_GET["clientId"];
$orderlist="orderlist".$clientId;
$query1 = "SELECT * FROM $orderlist";

$result1 = mysql_query($query1,$conn);
$i=1;
while($row = mysql_fetch_assoc($result1))
{
$if1 = $row["item"];
echo "<tr><td>$i</td>";
echo "<td>$if1</td>";
echo "<td><form action='m.php' method='get'><input type='checkbox' id='field" . $i . "' value=$if1 name='interests[]' checked ></input></td></tr>";
echo "<input type='hidden' name='clientId' value=$clientId />";
$i=$i+1;
}
echo "</table>";


echo "<input type='submit' value='DEL' id='hey' ></input>";
echo "</form>";


?>
<input type='submit' value='ORDER NOW' id='hm'></input>;


</html>
</body>






