<?php
//var_dump($_POST);
//connect and select the database 
$connect = mysql_connect("localhost","root","") or die('Database Not Connected. Please Fix the Issue! ' . mysql_error()); 
mysql_select_db("jsondb", $connect);
//echo "hello";
$_GET['interests'];
$clientId=$_GET['clientId'];


$orderlist="orderlist".$clientId;

foreach($_GET['interests'] as $c) {

   $query="DELETE FROM $orderlist WHERE item='$c'";
if(!mysql_query($query,$connect)) 
 { die('Error : Query Not Executed. Please Fix the Issue! ' . mysql_error());
 } 
 else{ echo "Data remove Successully!!!"; }
 
}




header("Location:http://localhost/details2/cart1.php?clientId=".$clientId);
exit;
?>