<?php
$connect = mysql_connect("localhost","root","") or die('Database Not Connected. Please Fix the Issue! ' . mysql_error()); 
mysql_select_db("jsondb", $connect);


$str_json = file_get_contents('php://input');
$content = json_decode($str_json);
$item=$content->item;
$status=$content->status;
$clientId=$content->clientId;
$tab=$content->tab;
echo $tab;
$orderlist=$tab.$clientId;


$query = "INSERT INTO $orderlist(item,status) VALUES('$item','$status')";



 if(!mysql_query($query,$connect)) 
 { die('Error : Query Not Executed. Please Fix the Issue! ' . mysql_error());
 } 
 else{ echo "data succesfully sent!".$orderlist; }?>