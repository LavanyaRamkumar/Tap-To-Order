<?php
//connect and select the database 
$connect = mysql_connect("localhost","root","") or die('Database Not Connected. Please Fix the Issue! ' . mysql_error()); 
mysql_select_db("jsondb", $connect);
extract($_GET);
echo $weight;
echo $unit;


$st="st".$clientId;

$query1 ="insert into $st (i,unit,wpu) VALUES (1,'$unit','$weight')ON DUPLICATE KEY UPDATE unit='$unit',wpu='$weight'";
if(!mysql_query($query1,$connect)) 
 { die('Error : Query Not Executed. Please Fix the Issue! ' . mysql_error());
 } 
 else{ echo "Data1 Inserted Successully!!!"; }
 
 if(isset($num))
{$query2="insert into $st (i,num) VALUES (1,'$num')ON DUPLICATE KEY UPDATE num='$num'";
if(!mysql_query($query2,$connect)) 
 { die('Error : Query Not Executed. Please Fix the Issue! ' . mysql_error());
 } 
 else{ echo "Data1 Inserted Successully!!!"; }
}

 
 
header("Location:http://localhost/details2/ind.php?clientId=".$clientId);
exit;





?>

