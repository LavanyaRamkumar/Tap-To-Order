<?php
$conn = mysql_connect("localhost","root","");
mysql_select_db('test', $conn);
$username=$_POST["Name"];
$password=$_POST["Password"];
$password1=$_POST["Password"];
$email=$_POST["Email"];
$avail=$_POST["avail"];
echo $avail;



?>