<?php
$conn = mysqli_connect("localhost","root","","jsondb");
$username=$_POST["Name"];
$query="SELECT * FROM losers WHERE name='" . $_POST["Name"] . "' AND password = '". $_POST["Password"]."'";
		$result = mysqli_query($conn,$query);
		$count  = mysqli_num_rows($result);
		print $count;
		if($count>=1)
		{
			
$query1="SELECT table_id FROM `losers` WHERE name='$username'";
	$result1=mysqli_query($conn,$query1);
	if(mysqli_num_rows($result1)>0)
{
while($row = mysqli_fetch_assoc($result1))
{
$clientId = $row["table_id"];
}}
header("Location:http://localhost/details2/ind.php?clientId=".$clientId);
}
else
header("Location:http://localhost/kitchenette/web/index.html");
?>
