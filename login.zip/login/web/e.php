<?php
$conn = mysqli_connect("localhost","root","","jsondb");

$username=$_POST["Name"];
$password=$_POST["Password"];
$password1=$_POST["Password"];
$email=$_POST["Email"];
$avail=$_POST["avail"];
echo $avail;
mysqli_autocommit($conn,TRUE);
if(strcmp($avail,"Not available"))
{   
	$query="INSERT INTO losers (name,password,email) VALUES('$username','$password','$email')";
    $result = mysqli_query($conn,$query);
	$query1="SELECT table_id FROM `losers` WHERE name='$username'";
	$result1=mysqli_query($conn,$query1);
	if(mysqli_num_rows($result1)>0)
{
while($row = mysqli_fetch_assoc($result1))
{
$clientId = $row["table_id"];
}}
$newtb="newtb".$clientId;
$st="st".$clientId;
$pro="pro".$clientId;
$psl1="psl1".$clientId;
echo $newtb;
$sl1="sl1".$clientId;
$orderlist="orderlist".$clientId;
$porder="porder".$clientId;
	$query2="CREATE TABLE $newtb (`id` int(10) NOT NULL AUTO_INCREMENT,`created_at` datetime NOT NULL,`entry_id` int(11) NOT NULL,`field1` float NOT NULL,PRIMARY KEY (`id`))";

$result2=mysqli_query($conn,$query2) or die ("query not executed");

$query3="CREATE TABLE $sl1 (
 `id` int(10) NOT NULL,
 `item` varchar(20) NOT NULL,
 `threshold` int(11) NOT NULL,
 PRIMARY KEY (`id`)
)";
$result3=mysqli_query($conn,$query3);
$query4="CREATE TABLE $orderlist (
 `id` int(10) NOT NULL AUTO_INCREMENT,
 `item` varchar(25) NOT NULL,
 `status` varchar(25) NOT NULL,
 PRIMARY KEY (`id`)
)";
$result4=mysqli_query($conn,$query4);
$query5="CREATE TABLE $pro (`id` int(10) NOT NULL AUTO_INCREMENT,`created_at` datetime NOT NULL,`entry_id` int(11) NOT NULL,`field1` float NOT NULL,PRIMARY KEY (`id`))";
$result5=mysqli_query($conn,$query5);

$query6="CREATE TABLE $psl1 (
 `id` int(10) NOT NULL,
 `item` varchar(20) NOT NULL,
 PRIMARY KEY (`id`)
)";
$result6=mysqli_query($conn,$query6);
$query7="CREATE TABLE $porder (
 `id` int(10) NOT NULL AUTO_INCREMENT,
 `item` varchar(25) NOT NULL,
 `status` varchar(25) NOT NULL,
 PRIMARY KEY (`id`)
) ";
$result7=mysqli_query($conn,$query7);
$query8="CREATE TABLE $st (
 `i` int(4) NOT NULL AUTO_INCREMENT,
 `unit` varchar(20) NOT NULL,
 `wpu` int(6) NOT NULL,
 `num` int(10) NOT NULL,
 PRIMARY KEY (`i`)
)";
$result8=mysqli_query($conn,$query8);
header("Location: http://localhost/kitchenette/web/index.html");

	
}



?>