<?php
$conn = mysql_connect("localhost","root","");
mysql_select_db('test', $conn);
$username=$_GET["Name"];
//$password=$_POST["Password"];
//$password1=$_POST["Password"];
//$email=$_POST["Email"];
$query1 = "SELECT name FROM losers WHERE name = '$username'";

$result1 = mysql_query($query1,$conn);



//$count  = mysqli_num_rows($result,);
//Checks if the username is available or not

//Prints the result
if (mysql_num_rows($result1)==1) {
 echo "<span class='green'>This username already exits!</span>";
 
}
else{
 echo "<span class='red'>Not available</span>";
 //$query="INSERT INTO losers (name,password,email) VALUES('$username','$password','$email')";
//$result = mysql_query($query,$conn);
}


?>